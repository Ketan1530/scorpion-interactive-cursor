
const scorpion = document.getElementById("scorpion");
const scoreText = document.getElementById("score");
const gameOverScreen = document.getElementById("gameOver");

let mouseX = window.innerWidth / 2;
let mouseY = window.innerHeight / 2;

let scorpionX = Math.random() * window.innerWidth;
let scorpionY = Math.random() * window.innerHeight;

let speed = 2;
let score = 0;
let gameRunning = true;

document.addEventListener("mousemove", (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
});

function moveScorpion() {
  if (!gameRunning) return;

  let dx = mouseX - scorpionX;
  let dy = mouseY - scorpionY;
  let distance = Math.sqrt(dx * dx + dy * dy);

  if (distance > 1) {
    scorpionX += (dx / distance) * speed;
    scorpionY += (dy / distance) * speed;
  }

  scorpion.style.left = scorpionX + "px";
  scorpion.style.top = scorpionY + "px";

  checkCollision();
  requestAnimationFrame(moveScorpion);
}

function checkCollision() {
  const rect = scorpion.getBoundingClientRect();
  if (
    mouseX > rect.left &&
    mouseX < rect.right &&
    mouseY > rect.top &&
    mouseY < rect.bottom
  ) {
    endGame();
  }
}

setInterval(() => {
  if (gameRunning) {
    score += 10;
    scoreText.innerText = "Score: " + score;
  }
}, 1000);

setInterval(() => {
  if (gameRunning) {
    speed *= 1.2;
  }
}, 3000);

function endGame() {
  gameRunning = false;
  gameOverScreen.style.display = "flex";
}

gameOverScreen.addEventListener("click", () => {
  score = 0;
  speed = 2;
  scorpionX = Math.random() * window.innerWidth;
  scorpionY = Math.random() * window.innerHeight;
  scoreText.innerText = "Score: 0";
  gameRunning = true;
  gameOverScreen.style.display = "none";
  moveScorpion();
});

moveScorpion();
